# SODA CAN > 2026-06-04 9:53am
https://universe.roboflow.com/wayne-gogmk/soda-can-zzhc3

Provided by a Roboflow user
License: CC BY 4.0

