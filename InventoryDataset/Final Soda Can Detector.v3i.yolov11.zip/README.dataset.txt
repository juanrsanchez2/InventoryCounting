# Final Soda Can Detector > 2025-04-14 2:40pm
https://universe.roboflow.com/cmp497finalproject/final-soda-can-detector

Provided by a Roboflow user
License: CC BY 4.0

